//======================================================
// GLOBALS
//======================================================
var textToDisplay = "Nier: Automata Menu Header";
var onscreenString = "";
var glitchTimePerLetter = .05;
var timeSinceLastLetterGlitchStart = 0.0;
var currentLetterIndex = 0;
var lastUpdateTime = getCurrentTime();
var textElement= document.getElementsByClassName("glitch")[0];

//======================================================
// HELPERS
//======================================================
function getCurrentTime() {
	return (new Date()).getTime();
}

function getDeltaTime() {
	var currentTime = getCurrentTime();
	var dt = (currentTime - lastUpdateTime) / 1000.0;
	lastUpdateTime = currentTime;	
	return dt;
}

function randomChar() {
	// cap A to lower z, including symbols
	var char = randomRange(0, 57);	
	return String.fromCharCode(65 + char);
}

function randomRange(min, max) {
	return min + Math.floor(Math.random() * (max - min + 1));
}

//======================================================
// LOGIC
//======================================================
function update() {	
	var dt = getDeltaTime();	
	timeSinceLastLetterGlitchStart += dt;
		
	if(timeSinceLastLetterGlitchStart > glitchTimePerLetter) {
		++currentLetterIndex;
		timeSinceLastLetterGlitchStart = 0;
	}	
	
	if(currentLetterIndex < textToDisplay.length) {
		onscreenString = textToDisplay.substr(0, currentLetterIndex) + randomChar();
		var newString = onscreenString;
		requestAnimationFrame(update);
	}
	else
		onscreenString = textToDisplay;
		
	textElement.innerHTML = onscreenString;
}

requestAnimationFrame(update);

function refresh(e) {
	currentLetterIndex = 0;
	timeSinceLastLetterGlitchStart = 0.0;
	requestAnimationFrame(update);
}